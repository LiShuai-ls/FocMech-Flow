import os, glob,shutil
from obspy import read,UTCDateTime
import numpy as np
from obspy.geodetics import calc_vincenty_inverse
import tensorflow as tf

def cal_snr(tr,samples=20):#by Dr.Zhai
    pt = tr.stats.starttime+tr.stats.sac.a #从PhaseNet读取的到时
    tr_s = tr.copy().trim(pt - 1.5, pt + 1.5, fill_value=0, pad=True)
    tr_s.detrend('demean');tr_s.detrend('linear');tr_s.normalize()
    noises = np.sqrt(np.mean(np.square(tr_s[0:100])))  # [P-1.5s, P-0.5s]
    signals = np.max(np.abs(tr_s[130:150+samples]))  # [P-0.2s, P+0.2s]
    snrs = np.square(signals / noises)
    snrdbs = round(10 * np.log10(snrs),1)  # in dB

    return snrdbs

def caldistaz(evla, evlo, stala, stalo):  # loc1-evt;loc2-sta
    evla, evlo, stala, stalo=float(evla), float(evlo), float(stala), float(stalo)
    dist, amz, _ = calc_vincenty_inverse(evla, evlo, stala, stalo)  # lat,lon
    return dist / 1000, amz

def run_PhaseNet(work_dir):
    # obtained fname.csv eg. 20210518104930_25.6400_99.9360_14.00_3.8.csv
    eqnlist = os.listdir(f'{work_dir}/01wfs')
    for eqn in eqnlist:
        stalst = glob.glob(f'{work_dir}/01wfs/{eqn}/*')
        oplst=[]
        for sta in stalst:
            n = sta.split('\\')[1]
            oplst.append(n)
        with open(f'{work_dir}/02PhaseNet/fname_csv/{eqn}.csv','w') as op:
            op.write('fname' + '\n')
            [op.write(a+ '\n') for a in oplst]
    #run PhaseNet
    for eqn in eqnlist:
        if not os.path.exists(f'{work_dir}/02PhaseNet/results/{eqn}'):
            os.mkdir(f'{work_dir}/02PhaseNet/results/{eqn}')
        pre_dir='phasenet/predict.py'
        model_dir=f'{work_dir}/02PhaseNet/phasenet/model/190703-214543'   
        data_list = f'{work_dir}/02PhaseNet/fname_csv/{eqn}.csv'
        data_dir = f'{work_dir}/01wfs/{eqn}'
        result_dir=f'{work_dir}/02PhaseNet/results/{eqn}'
        # cmd命令中，‘python phasenet/predict.py --model=model/190703-214543’不能变
        cmd = f'python phasenet/predict.py --model=model/190703-214543 --data_list={data_list} --data_dir={data_dir} --format=sac --result_dir={result_dir}'
        os.system(cmd)

# 20230629
# def run_PhaseNet(work_dir):
#     # obtained fname.csv eg. 20210518104930_25.6400_99.9360_14.00_3.8.csv
#     eqnlist = os.listdir(f'{work_dir}/01wfs')
#     for eqn in eqnlist:
#         stalst = glob.glob(f'{work_dir}/01wfs/{eqn}/*')
#         oplst=[]
#         for sta in stalst:
#             n = sta.split('\\')[1]
#             oplst.append(n)
#         with open(f'{work_dir}/02PhaseNet/fname_csv/{eqn}.csv','w') as op:
#             op.write('fname' + '\n')
#             [op.write(a+ '\n') for a in oplst]
#     #run PhaseNet
#     for eqn in eqnlist:
#         if not os.path.exists(f'{work_dir}/02PhaseNet/results/{eqn}'):
#             os.mkdir(f'{work_dir}/02PhaseNet/results/{eqn}')
#         pre_dir=f'{work_dir}/02PhaseNet/phasenet/predict.py'
#         model_dir=f'{work_dir}/02PhaseNet/phasenet/model/190703-214543'   
#         data_list = f'{work_dir}/02PhaseNet/fname_csv/{eqn}.csv'
#         data_dir = f'{work_dir}/01wfs/{eqn}'
#         result_dir=f'{work_dir}/02PhaseNet/results/{eqn}'
#         cmd = f'python {pre_dir} --model={model_dir} --data_list={data_list} --data_dir={data_dir} --format=sac --result_dir={result_dir}'
#         os.system(cmd)

def write_atime2sac(work_dir):
    picklst=glob.glob(f'{work_dir}/02PhaseNet/results/*/picks.csv')
    for pick in picklst:
        eqn=pick.split('\\')[-2] #20190218B092108.000~29.090~102.390~25.0~2.3
        pickf=open(pick,'r');lines=pickf.readlines()[1:];pickf.close()
        ptime=[line for line in lines if 'HZ' in line and 'P' in line]
        prob_pick = [line for line in lines if 'HZ' in line and 'P' in line and float(line.split(',')[4]) > 0.60]#PhaseNet拾取概率大于。。。
        if len(prob_pick)>=10:
            for line in prob_pick:
                pt=UTCDateTime(line.split(',')[3]);sta=line.strip().split(',')[-1]#'R3.ZD83.2020230012339.00.BHZ'
                st=read(f'{work_dir}/01wfs/{eqn}/{sta}')
                atime=pt-st[0].stats.starttime
                st[0].stats.sac.a = atime #将P波到时写入sac头文件,写入之后一定要记得另存为sac！！！
                tr = st[0]
                # snr=cal_snr(tr, samples=20)
                # if snr>10.0:
                if not os.path.exists(f'{work_dir}/02PhaseNet/write_atime_wfs/{eqn}'):
                    os.mkdir(f'{work_dir}/02PhaseNet/write_atime_wfs/{eqn}')
                tr.write(f'{work_dir}/02PhaseNet/write_atime_wfs/{eqn}/{sta}', format='SAC') #输出数量可能会不一样，因为有的P波极性达不到0.6
    #删除小于10个极性的事件
    files = glob.glob(f'{work_dir}/02PhaseNet/write_atime_wfs/*')  
    oflst=[]
    for file in files:
        if len(glob.glob(file+'/*')) < 10:  # 如果子文件为空
            oflst.append(file+'\n')
            shutil.rmtree(file) #删除非空文件夹
            # os.rmdir(file)  # 删除这个空文件夹


def run_DiTing(work_dir):
    diting_motion = tf.keras.models.load_model('03DiTing2CHNYTX/DiTingMotionJul/DiTingMotionJul.hdf5',compile = False)
    data_length = 128
    half_len = 64
    temp_data_X = np.zeros([int(data_length), 2])
    temp_data_Y = np.zeros([2, 3])

    remap={
        ord('U') : '+',
        ord('C') : '+',
        ord('R') : '-',
        ord('D') : '-',
        ord('g') : '1',
        ord('n') : '2',
    } #将震相中的UD替换成格点尝试法需要的格式

    #按事件预测输出
    # path='E:/workspace/2023_0325XC/00test/19_21PnetDtMpFMS'
    opfs=os.listdir(f'{work_dir}/02PhaseNet/write_atime_wfs')
    for eqn in opfs:
        if not os.path.exists(f'{work_dir}/03DiTing2CHNYTX/cutwfs/{eqn}'):
            os.mkdir(f'{work_dir}/03DiTing2CHNYTX/cutwfs/{eqn}')

    DTMpre=[];human=[]
    for eqn in opfs: #20200417B051622.800~28.958~102.473~24.0~1.6
        stalst=glob.glob(f'{work_dir}/02PhaseNet/write_atime_wfs/{eqn}/*')
        oplst=[]
        for sta in stalst:
            n = sta.split('\\')[1]
            st = read(sta)
            stn = st[0].stats.station;net = st[0].stats.network
            pt=st[0].stats.starttime+st[0].stats.sac.a
            trace = st[0].trim(pt-2, pt + 2, fill_value=0, pad=True)
            trace.write(f'{work_dir}/03DiTing2CHNYTX/cutwfs/{eqn}/{n}', format='SAC')
            stla = st[0].stats.sac.stla;stlo = st[0].stats.sac.stlo
            # evla=st[0].stats.sac.evla;evlo=st[0].stats.sac.evlo;evdp=st[0].stats.sac.evdp #sac头文件中包含事件信息
            evla = eqn.split('_')[1]
            evlo = eqn.split('_')[2]
            evdp = eqn.split('_')[3] #'8'
            data = trace;p_t = 200;half_len = 64
            # 方法1：以P震相为中心，前后采样64个点，组成128维度矩阵
            temp_data_X[:, 0] = data[p_t - half_len: p_t + half_len]
            # 方法2：直接输入到时
            # ptime = '2021-05-18T10:49:47.898438Z'
            # p_t = obspy.UTCDateTime(ptime)
            # temp_data_X[:, 0] = trace.slice(p_t - (half_len - 1) * 0.01, p_t + half_len * 0.01).data  # 如果不减一就是129个采样点
            # 归一化
            temp_data_X[:, 0] -= np.mean(temp_data_X[:, 0])
            norm_factor = np.max(np.abs(temp_data_X[:, 0]))
            if norm_factor == 0:
                pass
            else:
                temp_data_X[:, 0] /= norm_factor
            # 第二个通道，对震相垂直分量按P波到时作差分
            diff_data = np.diff(temp_data_X[half_len:, 0])
            diff_sign_data = np.sign(diff_data)
            temp_data_X[half_len + 1:, 1] = diff_sign_data[:]
            # 模型预测
            fmp_list = ['U', 'D']
            pred_res = diting_motion.predict(temp_data_X.reshape([1, 128, 2]))
            pred_fmp = (pred_res['T0D0'] + pred_res['T0D1'] + pred_res['T0D2'] + pred_res['T0D3']) / 4
            pred_cla = (pred_res['T1D0'] + pred_res['T1D1'] + pred_res['T1D2'] + pred_res['T1D3']) / 4
            pre_results = fmp_list[np.argmax(pred_fmp[0, :2])]  # 分两类：U，D
            dist, amz = caldistaz(evla, evlo, stla, stlo)
            # if st[0].stats.sac.dist>130.0: #判断是Pn还是Pg
            if dist > 130.0:  # 判断是Pn还是Pg
                pol='2'
            else:
                pol='1'
            # pol='1'
            pre_pol=pre_results.translate(remap)+pol #组合+、-和Pg(1)Pn(2)的格点尝试法格式
            op = net + '  ' + stn + '  ' + str(stla) + '  ' + str(stlo) + '  ' + '-12345.0000' + '  ' + str(evla) + '  ' + str(evlo) + '  ' + str(evdp) + '  ' + pre_pol
            oplst.append(op + '\n')
            DTMpre.append(pre_results)
        with open(f'{work_dir}/03DiTing2CHNYTX/DT2CHNYTX/DT{eqn}.csv','w') as mf:
            [mf.write(a) for a in oplst]
        with open(f'{work_dir}/04Focal_mech_CHNYTX/Pre_GT_v1.4/LIST2LIST/input_list/DT{eqn}.csv','w') as mf:
            [mf.write(a) for a in oplst]