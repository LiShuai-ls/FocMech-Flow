import os,math
from obspy.core import UTCDateTime,read
import numpy as np
from scipy.signal import detrend
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
plt.rcParams["font.sans-serif"] = "Times New Roman"#自定义字体

eq_array=np.loadtxt('D:/file/Scripts/2022_07DiTingMotion/DiTingMotionJul/01DiTingMotion_res_test&analyse/画527条识别错误的/norealizedlst.txt',dtype='str',delimiter=',')
fig, ax = plt.subplots(1, 4, sharex=True,sharey=True,  figsize=(12, 12))#画2*2张图，行*列,figsize(宽，高)
time = np.arange(int(100 * sum([0, 4]))) / 100  # 波形时间
# yticks, yticklabels = [], []
#第一个子图
for i in range(0,20):
    stream = read(f'E:/workspace/YangBiEq/final_eq/data/cutwfs/*/{eq_array[i,0]}')
    tr = stream[0].detrend('demean').detrend('linear');tr.normalize()
    swin = tr.data[199:250]  # 0.5s
    nwin = tr.data[50:199]  # 1.5s
    snr = np.max(np.abs(swin)) / np.max(np.abs(nwin));snr = round(snr, 1)
    SNRlg = round(math.log(snr, 10),1)
    ax[0].plot(time, tr.data[0:400] + i * 2.0, linewidth=0.5);ax[0].text(0.1, 2 * i + 0.2, round(snr, 1))
    # yticklabels.append(tr.stats.station)
    # yticks.append(i * 2.0)
    if eq_array[i,2] == 'U' and eq_array[i,3] == 'U': #eq_array[i,2]=Man_ud, eq_array[i,3]=sm_Ud
        ax[0].arrow(1.4, 2 * i - 0.3, 0, 0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax[0].arrow(1.7, 2 * i - 0.3, 0, 0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
        # plt.arrow(x轴坐标，y轴坐标，dx偏移量，dy偏移(正数eg +1代表箭头向上tail长度为1，-1箭头向下)，箭头由两部分组成，head和tail,长度一样就好)
    elif eq_array[i,2] == 'U' and eq_array[i,3] == 'D':
        ax[0].arrow(1.4, 2 * i - 0.3, 0, 0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax[0].arrow(1.7, 2 * i + 0.3, 0, -0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
    elif eq_array[i,2] == 'D' and eq_array[i,3] == 'U':
        ax[0].arrow(1.4, 2 * i + 0.3, 0, -0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax[0].arrow(1.7, 2 * i - 0.3, 0, 0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
    elif eq_array[i,2] == 'D' and eq_array[i,3] == 'D':
        ax[0].arrow(1.4, 2 * i + 0.3, 0, -0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax[0].arrow(1.7, 2 * i + 0.3, 0, -0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
# plt.yticks(yticks, yticklabels)#在y轴画台站名称
#第二个子图

for i in range(20,40):
    stream = read(f'E:/workspace/YangBiEq/final_eq/data/cutwfs/*/{eq_array[i,0]}')
    tr = stream[0].detrend('demean').detrend('linear');tr.normalize()
    swin = tr.data[199:250]  # 0.5s
    nwin = tr.data[50:199]  # 1.5s
    snr = np.max(np.abs(swin)) / np.max(np.abs(nwin));snr = round(snr, 1)
    SNRlg = round(math.log(snr, 10),1)
    ax[1].plot(time, tr.data[0:400] + (i-20) * 2.0, linewidth=0.5);ax[1].text(0.1, 2 * (i-20) + 0.2, round(snr, 1))
    if eq_array[i,2] == 'U' and eq_array[i,3] == 'U': #eq_array[i,2]=Man_ud, eq_array[i,3]=sm_Ud
        ax[1].arrow(1.4, 2 * (i-20) - 0.3, 0, 0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax[1].arrow(1.7, 2 * (i-20) - 0.3, 0, 0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
        # plt.arrow(x轴坐标，y轴坐标，dx偏移量，dy偏移(正数eg +1代表箭头向上tail长度为1，-1箭头向下)，箭头由两部分组成，head和tail,长度一样就好)
    elif eq_array[i,2] == 'U' and eq_array[i,3] == 'D':
        ax[1].arrow(1.4, 2 * (i-20) - 0.3, 0, 0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax[1].arrow(1.7, 2 * (i-20) + 0.3, 0, -0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
    elif eq_array[i,2] == 'D' and eq_array[i,3] == 'U':
        ax[1].arrow(1.4, 2 * (i-20) + 0.3, 0, -0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax[1].arrow(1.7, 2 * (i-20) - 0.3, 0, 0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
    elif eq_array[i,2] == 'D' and eq_array[i,3] == 'D':
        ax[1].arrow(1.4, 2 * (i-20) + 0.3, 0, -0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax[1].arrow(1.7, 2 * (i-20) + 0.3, 0, -0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
#第三个子图
for s in range(40,60):
    stream = read(f'E:/workspace/YangBiEq/final_eq/data/cutwfs/*/{eq_array[s,0]}')
    tr = stream[0].detrend('demean').detrend('linear');tr.normalize()
    swin = tr.data[199:250]  # 0.5s
    nwin = tr.data[50:199]  # 1.5s
    snr = np.max(np.abs(swin)) / np.max(np.abs(nwin));snr = round(snr, 1)
    SNRlg = round(math.log(snr, 10),1)
    i = s - 40
    ax[2].plot(time, tr.data[0:400] + i * 2.0, linewidth=0.5);ax[2].text(0.1, 2 * i + 0.2, round(snr, 1))
    if eq_array[s,2] == 'U' and eq_array[s,3] == 'U': #eq_array[i,2]=Man_ud, eq_array[i,3]=sm_Ud
        ax[2].arrow(1.4, 2 * i - 0.3, 0, 0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax[2].arrow(1.7, 2 * i - 0.3, 0, 0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
        # plt.arrow(x轴坐标，y轴坐标，dx偏移量，dy偏移(正数eg +1代表箭头向上tail长度为1，-1箭头向下)，箭头由两部分组成，head和tail,长度一样就好)
    elif eq_array[s,2] == 'U' and eq_array[s,3] == 'D':
        ax[2].arrow(1.4, 2 * i - 0.3, 0, 0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax[2].arrow(1.7, 2 * i + 0.3, 0, -0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
    elif eq_array[s,2] == 'D' and eq_array[s,3] == 'U':
        ax[2].arrow(1.4, 2 * i + 0.3, 0, -0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax[2].arrow(1.7, 2 * i - 0.3, 0, 0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
    elif eq_array[s,2] == 'D' and eq_array[s,3] == 'D':
        ax[2].arrow(1.4, 2 * i + 0.3, 0, -0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax[2].arrow(1.7, 2 * i + 0.3, 0, -0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
#第四个子图
for s in range(60,80):
    stream = read(f'E:/workspace/YangBiEq/final_eq/data/cutwfs/*/{eq_array[s,0]}')
    tr = stream[0].detrend('demean').detrend('linear');tr.normalize()
    swin = tr.data[199:250]  # 0.5s
    nwin = tr.data[50:199]  # 1.5s
    snr = np.max(np.abs(swin)) / np.max(np.abs(nwin));snr = round(snr, 1)
    SNRlg = round(math.log(snr, 10),1)
    i = s - 60
    ax[3].plot(time, tr.data[0:400] + i * 2.0, linewidth=0.5);ax[3].text(0.1, 2 * i + 0.2, round(snr, 1))
    if eq_array[s,2] == 'U' and eq_array[s,3] == 'U': #eq_array[i,2]=Man_ud, eq_array[i,3]=sm_Ud
        ax[3].arrow(1.4, 2 * i - 0.3, 0, 0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax[3].arrow(1.7, 2 * i - 0.3, 0, 0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
        # plt.arrow(x轴坐标，y轴坐标，dx偏移量，dy偏移(正数eg +1代表箭头向上tail长度为1，-1箭头向下)，箭头由两部分组成，head和tail,长度一样就好)
    elif eq_array[s,2] == 'U' and eq_array[s,3] == 'D':
        ax[3].arrow(1.4, 2 * i - 0.3, 0, 0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax[3].arrow(1.7, 2 * i + 0.3, 0, -0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
    elif eq_array[s,2] == 'D' and eq_array[s,3] == 'U':
        ax[3].arrow(1.4, 2 * i + 0.3, 0, -0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax[3].arrow(1.7, 2 * i - 0.3, 0, 0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
    elif eq_array[s,2] == 'D' and eq_array[s,3] == 'D':
        ax[3].arrow(1.4, 2 * i + 0.3, 0, -0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax[3].arrow(1.7, 2 * i + 0.3, 0, -0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)

#legend
Manlegend=mpatches.Patch(color='blue', label='Man')
AIlegend=mpatches.Patch(color='red', label='SmartMotion')
plt.legend(bbox_to_anchor=(0.94,0.96),bbox_transform=fig.transFigure,handles=[AIlegend,Manlegend],loc = 'upper right')

xticks = [r for r in range(0, 5)]
xticklabels = [r for r in xticks]
plt.xticks(xticks, xticklabels)
# plt.yticks(yticks, yticklabels)
# plt.ylim([-2, (i-20) * 2])
for i in range(0,4):
    ax[i].set_xlabel('Time(s)')
    # ax[i].set_ylabel('Station Name')
    ax[i].vlines(2, 0, 1, transform=ax[i].get_xaxis_transform(), colors='r', linewidth=1,linestyle='--')
ax[0].set_ylabel('Waveforms')
fig.suptitle('DiTingMotion “-” Earthquake Waveforms', fontsize=16)
plt.tight_layout()# 自动调整子图参数以提供指定的填充
plt.savefig(f'test_norealized.png',dpi=720)
plt.close()
