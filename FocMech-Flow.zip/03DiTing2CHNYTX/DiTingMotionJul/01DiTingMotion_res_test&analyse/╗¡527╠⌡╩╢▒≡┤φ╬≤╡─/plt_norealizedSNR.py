import os,math
from obspy.core import UTCDateTime,read
import numpy as np
from scipy.signal import detrend
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
plt.rcParams["font.sans-serif"] = "Times New Roman"#自定义字体

eq_array=np.loadtxt('D:/file/Scripts/2022_07DiTingMotion/DiTingMotionJul/01DiTingMotion_res_test&analyse/画527条识别错误的/norealizedlst.txt',dtype='str',delimiter=',')

all_snr=[];snr15=[]
for i in range(0,len(eq_array)):
    stream = read(f'E:/workspace/YangBiEq/final_eq/data/cutwfs/*/{eq_array[i,0]}')
    tr = stream[0].detrend('demean').detrend('linear');tr.normalize()
    swin = tr.data[199:250]  # 0.5s
    nwin = tr.data[50:199]  # 1.5s
    snr = np.max(np.abs(swin)) / np.max(np.abs(nwin))
    snr = round(snr, 1)
    SNRlg = round(math.log(snr, 10),1)
    all_snr.append(eq_array[i,0]+','+eq_array[i,2]+','+eq_array[i,3]+','+str(snr)+','+str(SNRlg))
    if snr>15:
        snr15.append(eq_array[i,0]+','+eq_array[i,2]+','+eq_array[i,3]+','+str(snr)+','+str(SNRlg))
    #20210518T105009.990000.YN.ZOD.BHZ.SAC,Man_Ud,sm_Ud,snr,SNRlg
fig, ax = plt.subplots(figsize=(4, 10))#画2*2张图，行*列,figsize(宽，高)
time = np.arange(int(100 * sum([0, 4]))) / 100  # 波形时间
yticks, yticklabels = [], []
i=0
for s in snr15:
    sta,Man_Ud,sm_Ud,snr,SNRlg=s.split(',')
    stream = read(f'E:/workspace/YangBiEq/final_eq/data/cutwfs/*/{sta}')
    tr = stream[0].detrend('demean').detrend('linear');tr.normalize()
    swin = tr.data[199:250]  # 0.5s
    nwin = tr.data[50:199]  # 1.5s
    snr = np.max(np.abs(swin)) / np.max(np.abs(nwin));snr = round(snr, 1)
    SNRlg = round(math.log(snr, 10),1)
    ax.plot(time, tr.data[0:400] + i * 2.0, linewidth=0.5);ax.text(0.1, 2 * i + 0.2, round(snr, 1))
    yticklabels.append(tr.stats.station)
    yticks.append(i * 2.0)
    if Man_Ud == 'U' and sm_Ud == 'U': #eq_array[i,2]=Man_ud, eq_array[i,3]=sm_Ud
        ax.arrow(1.4, 2 * i - 0.3, 0, 0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax.arrow(1.7, 2 * i - 0.3, 0, 0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
        # plt.arrow(x轴坐标，y轴坐标，dx偏移量，dy偏移(正数eg +1代表箭头向上tail长度为1，-1箭头向下)，箭头由两部分组成，head和tail,长度一样就好)
    elif Man_Ud == 'U' and sm_Ud == 'D':
        ax.arrow(1.4, 2 * i - 0.3, 0, 0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax.arrow(1.7, 2 * i + 0.3, 0, -0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
    elif Man_Ud == 'D' and sm_Ud == 'U':
        ax.arrow(1.4, 2 * i + 0.3, 0, -0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax.arrow(1.7, 2 * i - 0.3, 0, 0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
    elif Man_Ud == 'D' and sm_Ud == 'D':
        ax.arrow(1.4, 2 * i + 0.3, 0, -0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax.arrow(1.7, 2 * i + 0.3, 0, -0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
    i=i+1

#legend
Manlegend=mpatches.Patch(color='blue', label='Man')
AIlegend=mpatches.Patch(color='red', label='SmartMotion')
plt.legend(bbox_to_anchor=(0.94,0.935),bbox_transform=fig.transFigure,handles=[AIlegend,Manlegend],loc = 'upper right')

ax.set_xlabel('Time(s)')
ax.set_ylabel('Station Name')
ax.vlines(2, 0, 1, transform=ax.get_xaxis_transform(), colors='r', linewidth=1,linestyle='--')
xticks = [r for r in range(0, 5)]
xticklabels = [r for r in xticks]
plt.xticks(xticks, xticklabels)
plt.yticks(yticks, yticklabels)
fig.suptitle('DiTingMotion “-” Eq wfs SNR>15', fontsize=16)
plt.tight_layout()# 自动调整子图参数以提供指定的填充
plt.savefig(f'pltSNR_over15.png',dpi=720)
plt.close()


'''    

#画SNR分布直方图
fig, ax = plt.subplots(figsize=(8,10))
allsnr=[float(t.split(',')[0]) for t in all_snr]
ax.hist(allsnr, bins=30,color='#63b2ee',linewidth=1, edgecolor="black",label='SNR',alpha=0.8)

# ax.xaxis.set_major_locator(plt.MaxNLocator(7))#设置刻度为7
ax.set_ylabel('Numbers');ax.set_xlabel('SNR');ax.set_title('Earthquake Waveforms SNR')
# ax.legend()
fig.tight_layout()
plt.savefig('DTnorealized_SNR.png',dpi=720)
plt.close()
'''
