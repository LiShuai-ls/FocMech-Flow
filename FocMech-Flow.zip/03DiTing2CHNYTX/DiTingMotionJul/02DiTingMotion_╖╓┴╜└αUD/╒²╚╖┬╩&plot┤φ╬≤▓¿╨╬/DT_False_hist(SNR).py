import os,math
from obspy.core import UTCDateTime,read
import numpy as np
from scipy.signal import detrend
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
plt.rcParams["font.sans-serif"] = "Times New Roman"#自定义字体

allManlist = [];allAIlist = []
names=os.listdir('D:/file/Scripts/2022_07DiTingMotion/DiTingMotionJul/02DiTingMotion_分两类UD/Output')
for name in names:
    name=name[6:]
    Manlist = []
    AIlist = []
    # nowfs = []如果想输出元素到多个文件夹，空列表放在这里是错误的！数据遗漏
    f=open(f'D:/file/Scripts/2022_07DiTingMotion/DiTingMotionJul/02DiTingMotion_分两类UD/Output/Output{name}','r');lines=f.readlines();f.close()
    for line in lines:
        line=line.strip()
        sta,  pha, Man_Ud,sm_Ud,Dt_Ud, dist = line.split(',')
        Man=sta+','+pha+','+Man_Ud
        AI=sta+','+pha+','+Dt_Ud
        allManlist.append(Man+'\n');allAIlist.append(AI+'\n')
        Manlist.append(Man+'\n')
        AIlist.append(AI+'\n')
        single_set=set(Manlist)&set(AIlist)#单个地震事件SNR交集
        noset = set(Manlist) - set(AIlist)#差集
allset = set(allManlist) & set(allAIlist)  # 所有地震SNR交集
all_noset=set(allManlist) - set(allAIlist)#差集
all_snr=[]
for no in all_noset:
    no=no.strip();pt = UTCDateTime(no[0:22]);sta, pha, Ud = no.split(',')
    st = read(f'E:/workspace/YangBiEq/final_eq/data/cutwfs/*/{sta}')
    tr = st[0].detrend('demean').detrend('linear')
    tr.normalize()
    # calSNR
    swin = tr.data[199:250]  # 0.5s
    nwin = tr.data[50:199]  # 1.5s
    snr = np.max(np.abs(swin)) / np.max(np.abs(nwin));snr = round(snr, 1)
    SNRlg = round(math.log(snr, 10), 1)
    all_snr.append(str(snr)+','+str(SNRlg))
#画SNR分布直方图

fig, ax = plt.subplots(figsize=(8,10))
allsnr=[float(t.split(',')[0]) for t in all_snr]
ax.hist(allsnr, bins=30,color='#63b2ee',linewidth=1, edgecolor="black",label='SNR',alpha=0.8)

# ax.xaxis.set_major_locator(plt.MaxNLocator(7))#设置刻度为7
ax.set_ylabel('Numbers');ax.set_xlabel('SNR');ax.set_title('DiTingMotion False SNR')
# ax.legend()
fig.tight_layout()
plt.savefig('DT_False_hist(SNR).png',dpi=720)
plt.close()



