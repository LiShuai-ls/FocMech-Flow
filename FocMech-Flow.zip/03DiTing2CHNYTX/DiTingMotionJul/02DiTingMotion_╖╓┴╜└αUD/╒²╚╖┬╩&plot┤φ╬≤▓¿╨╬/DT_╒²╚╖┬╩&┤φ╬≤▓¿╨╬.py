import os,math
from obspy.core import UTCDateTime,read
import numpy as np
from scipy.signal import detrend
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
plt.rcParams["font.sans-serif"] = "Times New Roman"#自定义字体

allManlist = [];allAIlist = [];allTsnr=[];allFsnr=[]
names=os.listdir('D:/file/Scripts/2022_07DiTingMotion/DiTingMotionJul/02DiTingMotion_分两类UD/Output')
for name in names:
    name=name[6:]
    Manlist = []
    AIlist = []
    # nowfs = []如果想输出元素到多个文件夹，空列表放在这里是错误的！数据遗漏
    f=open(f'D:/file/Scripts/2022_07DiTingMotion/DiTingMotionJul/02DiTingMotion_分两类UD/Output/Output{name}','r');lines=f.readlines();f.close()
    for line in lines:
        line=line.strip()
        sta,  pha, Man_Ud,sm_Ud,Dt_Ud, dist = line.split(',')
        Man=sta+','+pha+','+Man_Ud
        AI=sta+','+pha+','+Dt_Ud
        allManlist.append(Man+'\n');allAIlist.append(AI+'\n')
        Manlist.append(Man+'\n')
        AIlist.append(AI+'\n')
        single_set=set(Manlist)&set(AIlist)#单个地震事件SNR交集
        noset = set(Manlist) - set(AIlist)#差集
allset = set(allManlist) & set(allAIlist)  # 所有地震SNR交集
all_noset=set(allManlist) - set(allAIlist)#差集
streams=[];Udlst=[]
for no in all_noset:
    no=no.strip();pt = UTCDateTime(no[0:22]);sta, pha, Ud = no.split(',')
    stream = read(f'E:/workspace/YangBiEq/final_eq/data/cutwfs/*/{sta}')
    streams.append(stream);Udlst.append(Ud)
# fig, ax = plt.subplots(2, 2, sharex=True, sharey=True, figsize=(6, 10))#画2*2张图，行*列
fig, ax = plt.subplots(figsize=(4, 18))#画一张图
time = np.arange(int(100 * sum([0, 4]))) / 100  # 波形时间
i = 0
yticks, yticklabels = [], []
for st,Man_ud in zip(streams,Udlst):
    tr=st[0].detrend('demean').detrend('linear')
    tr.normalize()
    # calSNR
    swin = tr.data[199:250]  # 0.5s
    nwin = tr.data[50:199]  # 1.5s

    snr = np.max(np.abs(swin)) / np.max(np.abs(nwin));snr = round(snr, 1)
    SNRlg = round(math.log(snr, 10),1)
    ax.plot(time, tr.data[0:400] + i * 2.0, linewidth=0.5);ax.text(0.1, 2 * i + 0.2, round(snr, 1));ax.set_title('DiTingMotion Unidentification Waves')
    yticklabels.append(tr.stats.station)
    yticks.append(i * 2.0)
    if Man_ud == 'U':
        plt.arrow(1.4, 2 * i - 0.3, 0, 0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        # plt.text(130, 2 * i + 0.2, 'Man')
        plt.arrow(1.7, 2 * i + 0.3, 0, -0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
        # plt.text(190, 2 * i + 0.2, 'AI')
        # plt.arrow(x轴坐标，y轴坐标，dx偏移量，dy偏移(正数eg +1代表箭头向上tail长度为1，-1箭头向下)，箭头由两部分组成，head和tail,长度一样就好)
    else:
        plt.arrow(1.4, 2 * i + 0.3, 0, -0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        # plt.text(130, 2 * i + 0.2, 'Man')
        plt.arrow(1.7, 2 * i - 0.3, 0, 0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
        # plt.text(190, 2 * i + 0.2, 'AI')
    i = i + 1
xticks = [r for r in range(0, 5)]
xticklabels = [r for r in xticks]
plt.xticks(xticks, xticklabels)
plt.yticks(yticks, yticklabels)
plt.ylim([-2, i * 2])

#legend
Manlegend=mpatches.Patch(color='blue', label='Man')
AIlegend=mpatches.Patch(color='red', label='AI')
ax.legend(bbox_to_anchor=(0.94,0.935),bbox_transform=fig.transFigure,handles=[AIlegend,Manlegend],loc = 'upper right')


ax.set_xlabel('Time(s)')
ax.set_ylabel('Station Name')
ax.vlines(2, 0, 1, transform=ax.get_xaxis_transform(), colors='r', linewidth=1, linestyle='--')
plt.tight_layout()  # 自动调整子图参数以提供指定的填充
plt.savefig('DiTingMotion Unidentification Waves.png', dpi=720)
plt.close()



