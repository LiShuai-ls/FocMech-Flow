import os,math
from obspy.core import UTCDateTime,read
import numpy as np
from scipy.signal import detrend
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
plt.rcParams["font.sans-serif"] = "Times New Roman"#自定义字体


op_array=np.loadtxt('D:/file\Scripts/2022_07DiTingMotion/DiTingMotionJul/02DiTingMotion_分两类UD/Output/Output20210519175859_25.6550_99.9050_13.00_3.8.txt',dtype='str',delimiter=',')
fig, ax = plt.subplots(figsize=(4, 18))#画一张图
time = np.arange(int(100 * sum([0, 4]))) / 100  # 波形时间
# i = 0
yticks, yticklabels = [], []
for i in range(0,len(op_array)):
    sta,Man_Ud,sm_Ud,snr,SNRlg=s.split(',')
    stream = read(f'E:/workspace/YangBiEq/final_eq/data/cutwfs/*/{op_array[i,0]}')
    tr = stream[0].detrend('demean').detrend('linear');tr.normalize()
    swin = tr.data[199:250]  # 0.5s
    nwin = tr.data[50:199]  # 1.5s
    snr = np.max(np.abs(swin)) / np.max(np.abs(nwin));snr = round(snr, 1)
    SNRlg = round(math.log(snr, 10),1)
    ax.plot(time, tr.data[0:400] + i * 2.0, linewidth=0.5);ax.text(0.1, 2 * i + 0.2, round(snr, 1))
    yticklabels.append(tr.stats.station)
    yticks.append(i * 2.0)
    if op_array[i,2] == 'U' and op_array[i,4] == 'U':  # op_array[i,2]=Man_ud, eq_array[i,3]=sm_Ud
        ax.arrow(1.4, 2 * i - 0.3, 0, 0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax.arrow(1.7, 2 * i - 0.3, 0, 0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
        # plt.arrow(x轴坐标，y轴坐标，dx偏移量，dy偏移(正数eg +1代表箭头向上tail长度为1，-1箭头向下)，箭头由两部分组成，head和tail,长度一样就好)
    elif op_array[i,2] == 'U' and op_array[i,4] == 'D':
        ax.arrow(1.4, 2 * i - 0.3, 0, 0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax.arrow(1.7, 2 * i + 0.3, 0, -0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
    elif op_array[i,2] == 'D' and op_array[i,4] == 'U':
        ax.arrow(1.4, 2 * i + 0.3, 0, -0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax.arrow(1.7, 2 * i - 0.3, 0, 0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
    elif op_array[i,2] == 'D' and op_array[i,4] == 'D':
        ax.arrow(1.4, 2 * i + 0.3, 0, -0.5, color='b', width=0.02, head_width=0.1, head_length=0.3)
        ax.arrow(1.7, 2 * i + 0.3, 0, -0.5, color='r', width=0.02, head_width=0.1, head_length=0.3)
    # i = i + 1
xticks = [r for r in range(0, 5)]
xticklabels = [r for r in xticks]
plt.xticks(xticks, xticklabels)
plt.yticks(yticks, yticklabels)
plt.ylim([-2, i * 2])

#legend
Manlegend=mpatches.Patch(color='blue', label='Man')
AIlegend=mpatches.Patch(color='red', label='AI')
ax.legend(bbox_to_anchor=(0.94,0.935),bbox_transform=fig.transFigure,handles=[AIlegend,Manlegend],loc = 'upper right')


ax.set_xlabel('Time(s)')
ax.set_ylabel('Station Name')
ax.vlines(2, 0, 1, transform=ax.get_xaxis_transform(), colors='r', linewidth=1, linestyle='--')
plt.tight_layout()  # 自动调整子图参数以提供指定的填充
plt.savefig('DiTingMotion Unidentification Waves.png', dpi=720)
plt.close()