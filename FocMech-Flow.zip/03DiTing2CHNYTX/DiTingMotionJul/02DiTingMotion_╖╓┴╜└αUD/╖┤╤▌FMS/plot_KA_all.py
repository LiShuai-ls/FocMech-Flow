import matplotlib.pyplot as plt
# plt.rcParams["font.sans-serif"] = "Times New Roman"#自定义字体
paras={
    'axes.labelsize':18,'axes.titlesize':20,'font.family':'Times New Roman','xtick.labelsize':15,'ytick.labelsize':15,'legend.fontsize':15,
    'font.size':15,
}
plt.rcParams.update(paras)

#Aftershocks consistence
x=[46.24,41.81,24.01,50.30,37.86,18.05,40.35,57.42,23.72,33.19,43.94,79.72,19.36,44.95,17.04,30.12,12.09,28.58,15.57,58.33,57.19,14.46,
62.06,98.89,33.03,37.17,42.34,52.85,38.12,32.39,23.60,31.31,88.98,19.68,60.64,56.68,80.33,47.82,29.35,48.34,21.80,53.12,25.71,44.12,
19.43,49.46, 6.72,26.75,15.06,40.38,45.49,66.13,37.14,28.86,81.85,23.46,69.96,23.69,25.56,70.53,10.74,59.04,78.14,50.72,51.51,10.74,
38.65,71.46,91.92,38.04,52.24,34.00,12.60,25.44,51.89,37.11,46.50,70.70,32.28,83.26,46.26,38.84,43.46,66.19,30.80]
fig, ax = plt.subplots(figsize=(8,10))
ax.hist(x,bins=20,color='#63b2ee',linewidth=1, edgecolor="black",label='KA angle',alpha=0.8)
ax.xaxis.set_major_locator(plt.MaxNLocator(15))#设置刻度为
ax.set_ylabel('Numbers');ax.set_xlabel('Rotation Angle(°)');ax.set_title('Aftershocks of 2021YangBi Earthquake Sequence')
ax.legend()
ax.vlines(30, 0, 1, transform=ax.get_xaxis_transform(), colors='r', linewidth=3)
# plt.show()
plt.tight_layout()# 自动调整子图参数以提供指定的填充
plt.savefig(f'plot_KA_Aftershocks.png',dpi=720)
plt.close()
'''
#foreshocks consistence
x=[13.87,19.31,28.38,17.14,25.05,25.43, 4.87,29.50, 7.05,15.72,29.49,23.85,22.87,42.64,18.35]
fig, ax = plt.subplots(figsize=(8,10))
ax.hist(x,bins=12,color='#63b2ee',linewidth=1, edgecolor="black",label='KA angle',alpha=0.8)
ax.xaxis.set_major_locator(plt.MaxNLocator(10))#设置刻度为10份
ax.set_ylabel('Numbers');ax.set_xlabel('Rotation Angle(°)');ax.set_title('Foreshocks of 2021YangBi Earthquake Sequence')
ax.legend()
ax.vlines(30, 0, 1, transform=ax.get_xaxis_transform(), colors='r', linewidth=3)
# plt.show()
plt.tight_layout()# 自动调整子图参数以提供指定的填充
plt.savefig(f'plot_KA_foreshocks.png',dpi=720)
plt.close()
'''