import os,re
'''
#AI
namedir='E:/workspace/YangBiEq/final_eq/files/Smart2FMS/AI'
output_gt='D:/file/Scripts/Smart_FocalMS/Ge_FMS/results/2022-06-07删选上次结果/AI_gt1.csv'
gtpath='D:/file/Scripts/Smart_FocalMS/Ge_FMS/results/2022-06-07删选上次结果/AI'

names = os.listdir(namedir)
allgt = open(output_gt, 'w')
allgt.write('name SK1 DA1 SA1 SK2 DA2 SA2  PAZ PPL TAZ TPL BAZ BPL  MDB  RMS  REL'+'\n')
for name in names:
    name=name[:-4]
    gtlist = []
    with open(gtpath+f'/{name}.gt', 'r') as f:
        lines1 = f.readlines()[-10:]
        for line in lines1:
            line = line.strip()
            a = '  '.join(re.findall(r"\d+\.?\d{3}", line))  # 正则匹配保留三位小数的字符串 \d+\.?\d{3}
            # 131 77  191  39 79  347  355 17   85  1  180 73  0.14 5.8 0.667
            if '0' in a:
                if a in line:
                    b = name + '  ' + line
                    gtlist.append(b + '\n')
        [allgt.write(r) for r in gtlist]
allgt.close()# 为何在开始时就打开allgt？因为只需要将全部内容输入到一个文档中，不需要循环打开关闭

# #Man
# namedir='E:/workspace/YangBiEq/final_eq/files/Smart2FMS/Man'
# output_gt='D:/file/Scripts/Smart_FocalMS/Ge_FMS/results/2022-06-07删选上次结果/Man_gt.csv'
# gtpath='D:/file/Scripts/Smart_FocalMS/Ge_FMS/results/2022-06-07删选上次结果/Man'
#
# names = os.listdir(namedir)
# allgt = open(output_gt, 'w')
# allgt.write('name SK1 DA1 SA1 SK2 DA2 SA2  PAZ PPL TAZ TPL BAZ BPL  MDB  RMS  REL'+'\n')
# for name in names:
#     name=name[:-4]
#     gtlist = []
#     with open(gtpath+f'/{name}.gt', 'r') as f:
#         lines1 = f.readlines()[-10:]
#         for line in lines1:
#             line = line.strip()
#             a = '  '.join(re.findall(r"\d+\.?\d{3}", line))  # 正则匹配保留三位小数的字符串 \d+\.?\d{3}
#             # 131 77  191  39 79  347  355 17   85  1  180 73  0.14 5.8 0.667
#             if '0' in a:
#                 if a in line:
#                     b = name + '  ' + line
#                     gtlist.append(b + '\n')
#         [allgt.write(r) for r in gtlist]
# allgt.close()# 为何在开始时就打开allgt？因为只需要将全部内容输入到一个文档中，不需要循环打开关闭
'''
#####################################################
#plot A,B,C from MDB and RMS
import math
import numpy as np
from obspy.core import read
from collections import Counter
import matplotlib.pyplot as plt
from scipy.signal import detrend
from matplotlib import font_manager
# font_manager._rebuild()
paras={
    'axes.labelsize':10,'axes.titlesize':15,'font.family':'Times New Roman','xtick.labelsize':10,'ytick.labelsize':10,'legend.fontsize':10,
    'font.size':10,
}
plt.rcParams.update(paras)

f=open('D:/file/Scripts/Smart_FocalMS/Ge_FMS/results/2022-06-07删选上次结果/AI_gt1.csv','r');lines=f.readlines()[1:];f.close()
eqn=[line.split()[0][2:] for line in lines]#20210518104930_25.6400_99.9360_14.00_3.8去掉'AI'
a=dict(Counter(eqn))#统计出现次数
A1=[key for key,value in a.items() if value==1];C1=[key for key,value in a.items() if value>1]#20210518104930_25.6400_99.9360_14.00_3.8
gts=[line.split()[0][2:]+','+line.split()[13]+','+line.split()[14] for line in lines]
Alist=[];C_list=[]#20210518104930_25.6400_99.9360_14.00_3.8
for gt in gts:
    name=gt.split(',')[0];MDB=gt.split(',')[1];RMS=gt.split(',')[2]
    #按俞春泉分类，计算A类
    if name in A1 and float(MDB)<=0.15 and float(RMS)<=15:
        Alist.append(gt.split(',')[0])
        #计算C类
    elif name in C1 or float(MDB)>=0.30:
        C_list.append(gt.split(',')[0])
        Clist=list(set(C_list))
A=len(Alist);C=len(Clist);B=len(set(eqn))-A-C
#'''
#Alist Clist
Atrs=[];A_all_snr=[]
for Aname in Alist:
    streams = read(f'E:/workspace/YangBiEq/final_eq/data/cutwfs/{Aname}/*.SAC')
    s=[]#单个事件的信噪比
    for st in streams:
        tr=st
        tr_s = tr.copy();tr_n = tr.copy()
        swin = detrend(tr.data[199:250])  # 0.5s
        nwin = detrend(tr.data[50:199])  # 1.5s
        snr = np.max(np.abs(swin)) / np.max(np.abs(nwin))
        lg_snr=math.log(snr, 10)#取对数
        s.append(snr);A_all_snr.append(snr) # A_all_snr.append(str(lg_snr))
    Average_SNR = sum(s) / len(streams)
    Atrs.append(Aname+','+str(len(streams))+','+str(Average_SNR))
A_stations=sum([int(l.split(',')[1]) for l in Atrs])/len(Atrs)#average stations
#caculate average SNR
# A_aveSNR=sum([float(l.split(',')[2]) for l in Atrs])/len(Atrs)#计算出每个事件的平均信噪比，再相加计算所有事件平均信噪比——得到每个事件的信噪比135
A_aveSNR=sum([float(l) for l in A_all_snr])/len(A_all_snr)#先计算每一条波形的信噪比再平均——得到每条波形的信噪比128
# with open('D:/file/Scripts/Smart_FocalMS/Ge_FMS/results/2022-06-07删选上次结果/A类.txt','w') as Af:
#     [Af.write(a+'\n') for a in Atrs]
Ctrs=[];C_all_snr=[]
for Cname in Clist:
    streams = read(f'E:/workspace/YangBiEq/final_eq/data/cutwfs/{Cname}/*.SAC')
    s=[]
    for st in streams:
        tr=st
        tr_s = tr.copy();tr_n = tr.copy()
        swin = detrend(tr.data[199:250])  # 0.5s
        nwin = detrend(tr.data[50:199])  # 1.5s
        snr = np.max(np.abs(swin)) / np.max(np.abs(nwin))
        lg_snr = math.log(snr, 10)  # 取对数
        s.append(snr);C_all_snr.append(snr) # C_all_snr.append(str(lg_snr))
        SumSNR=0
        for i in s:
            SumSNR+=i
    Average_SNR=SumSNR/len(streams)
    Ctrs.append(Cname+','+str(len(streams))+','+str(Average_SNR))
C_stations=sum([int(l.split(',')[1]) for l in Ctrs])/len(Ctrs)#average stations
# C_aveSNR=sum([float(l.split(',')[2]) for l in Ctrs])/len(Ctrs)#计算出每个事件的平均信噪比，再相加计算所有事件平均信噪比——得到每个事件的信噪比135
C_aveSNR=sum([float(l) for l in C_all_snr])/len(C_all_snr)#先计算每一条波形的信噪比再平均——得到每条波形的信噪比128
# with open('D:/file/Scripts/Smart_FocalMS/Ge_FMS/results/2022-06-07删选上次结果/C类.txt','w') as Cf:
#     [Cf.write(a+'\n') for a in Ctrs]
#'''
##############将计算得到的方位角作差得到gap最大空隙角
names=os.listdir('D:/file/Scripts/Smart_FocalMS/Ge_FMS/Focal_mech_Fang/Pre_GT_v1.4/LIST2LIST/output_list')
all_gap=[];gapdict=dict()
for name in names:
    gname=name[2:-4]#20210518104930_25.6400_99.9360_14.00_3.8
    f=open(f'D:/file/Scripts/Smart_FocalMS/Ge_FMS/Focal_mech_Fang/Pre_GT_v1.4/LIST2LIST/output_list/{name}','r');lines=f.readlines();f.close()
    Azimuth=sorted([float(line.split()[1]) for line in lines])#顺序,注意数据类型转换，若需要逆序，则sorted(xxx, reverse=True)
    gap1='{:.4}'.format(max([Azimuth[i]-Azimuth[i-1] for i in range(2,len(Azimuth))]))
    gap2='{:.4}'.format(Azimuth[1]+360-Azimuth[-1])#计算张角时，第一个角度和最后一个角度的值，这个值也要算,最小的一个角度后面再加360,再减去最后最大的那个
    gap=max(gap1,gap2)
    gapdict[gname]=gap
    all_gap.append(gname+','+str(gap))
Agap=sorted([float(a.split(',')[1]) for a in all_gap if a.split(',')[0] in Alist]);ave_Agap=sum(Agap)/len(Agap)
Cgap=sorted([float(a.split(',')[1]) for a in all_gap if a.split(',')[0] in Clist]);ave_Cgap=sum(Cgap)/len(Cgap)
'''
####plot A,B,C gap and station numbers

x1=np.arange(0,len(Atrs));x2=np.arange(0,len(Ctrs))
y1=sorted([line.split(',')[2] for line in Atrs]);y2=sorted([line.split(',')[2] for line in Ctrs])

fig, [ax1, ax2] = plt.subplots(2, 1, figsize=(10,15))
a1=ax1.bar(x1, y1 , width=0.5, label='Station Numbers')
ax1.set_ylabel('Station Numbers');ax1.set_xlabel('A Category EqNumbers')
# ax1.bar_label(a1, padding=2)
# ax1.set_ylim([0,60]);ax1.set_yticks(np.arange(0,60,1))#设置y轴范围及刻度
c1=ax2.bar(x2,y2, width=0.5, label='Station Numbers')
ax2.set_ylabel('Station Numbers');ax2.set_xlabel('C Category EqNumbers')
# ax2.bar_label(c1, padding=2)
fig.tight_layout()
plt.savefig('D:/file/Scripts/Smart_FocalMS/Ge_FMS/results/2022-06-07删选上次结果/A_stations gap.png',dpi=720)
plt.close()
# plt.show()
'''
'''

x = [0,3,6]  # the label locations
y=[45,9,47]
labels=['A','B','C']
width = 1  # the width of the bars

fig, ax = plt.subplots(figsize=(6,6))
rects1 = ax.bar(x, y, width,edgecolor="white", linewidth=0.7)


# Add some text for labels, title and custom x-axis tick labels, etc.
ax.set_ylabel('Numbers');ax.set_xlabel('Focal mechanism solutions category')
ax.set_title('2021.05.18-2021.06.02 YangBi Earthquakes')
ax.set_xticks(x, labels)
# ax.legend()

ax.bar_label(rects1, padding=1)#padding-label to bar distance

fig.tight_layout()
plt.savefig('D:/file/Scripts/Smart_FocalMS/Ge_FMS/results/2022-06-07删选上次结果/FMS_category.png',dpi=720)
plt.close()
# plt.show()
'''
