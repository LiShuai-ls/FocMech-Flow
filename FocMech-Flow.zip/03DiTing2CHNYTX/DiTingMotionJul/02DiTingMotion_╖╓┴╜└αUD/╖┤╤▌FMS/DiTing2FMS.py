import os
import numpy as np
# os.chdir('E:/workspace/YangBiEq/final_eq')
names = os.listdir('D:/file/Scripts/2022_07DiTingMotion/DiTingMotionJul/02DiTingMotion_分两类UD/Output')
stnf=open('stationinfo.txt','r');slines=stnf.readlines();stnf.close()
# names=['20210518104930_25.6400_99.9360_14.00_3.8.csv','20210518122028_25.6310_99.9350_16.00_3.4.csv']
for name in names:
    # eloc=name.split('_')[1]+'  '+name.split('_')[2]+'  '+name.split('_')[3]#深度是震相报告中的深度
    eloc = name.split('_')[1] + '  ' + name.split('_')[2] + '  ' +'7.5'
    FMSlist=[]
    inf=open(f'D:/file/Scripts/2022_07DiTingMotion/DiTingMotionJul/02DiTingMotion_分两类UD/Output/{name}', 'r');inlines = inf.readlines();inf.close()
    for inline,sline in zip(inlines,slines):
        inline = inline.strip();sta,pha,Man_Ud,sm_Ud,Dt_Ud,dist=inline.split(',')
        if 'Pg' in pha and 'U' in Dt_Ud:#DiTingMotion
            sta=sta[23:-8]#YN.WAD
            stalist=[sline for sline in slines if sta in sline.split(',')[0]]
            for st in stalist:
                st = st.strip();st = st.split(',')
                staloc = st[0].split('.')[0] + '  ' + st[0].split('.')[1] + '  ' + st[1] + '  ' + st[2]
                Ug = staloc + '  ' + '-12345.0000' + '  ' + eloc + '  ' + '+1'
                FMSlist.append(Ug+'\n')
        elif 'Pg' in pha and 'D' in Dt_Ud:#DiTingMotion
            sta=sta[23:-8]#YN.WAD
            stalist=[sline for sline in slines if sta in sline.split(',')[0]]
            for st in stalist:
                st = st.strip();st = st.split(',')
                staloc = st[0].split('.')[0] + '  ' + st[0].split('.')[1] + '  ' + st[1] + '  ' + st[2]
                Dg = staloc + '  ' + '-12345.0000' + '  ' + eloc+ '  ' + '-1'
                FMSlist.append(Dg+'\n')
        elif 'Pn' in pha and 'U' in Dt_Ud:#DiTingMotion
            sta=sta[23:-8]#YN.WAD
            stalist=[sline for sline in slines if sta in sline.split(',')[0]]
            for st in stalist:
                st = st.strip();st = st.split(',')
                staloc = st[0].split('.')[0] + '  ' + st[0].split('.')[1] + '  ' + st[1] + '  ' + st[2]
                Un = staloc + '  ' + '-12345.0000' + '  ' + eloc+ '  ' + '+2'
                FMSlist.append(Un+'\n')
        elif 'Pn' in pha and 'D' in Dt_Ud:#DiTingMotion
            sta=sta[23:-8]#YN.WAD
            stalist=[sline for sline in slines if sta in sline.split(',')[0]]
            for st in stalist:
                st = st.strip();st = st.split(',')
                staloc = st[0].split('.')[0] + '  ' + st[0].split('.')[1] + '  ' + st[1] + '  ' + st[2]
                Dn = staloc + '  ' + '-12345.0000' + '  ' + eloc+ '  ' + '-2'
                FMSlist.append(Dn+'\n')
    with open(f'DiTing2FMS/Dt{name[6:-4]}.csv','w') as fms:
        [fms.write(f) for f in FMSlist]
'''
#AI
for name in names:
    # eloc=name.split('_')[1]+'  '+name.split('_')[2]+'  '+name.split('_')[3]#深度是震相报告中的深度
    eloc = name.split('_')[1] + '  ' + name.split('_')[2] + '  ' + '7.5'
    FMSlist=[]
    inf=open(f'files/Output/Output{name}', 'r');inlines = inf.readlines();inf.close()
    for inline,sline in zip(inlines,slines):
        inline = inline.strip();inline=inline.split(',')
        if 'Pg' in inline[3] and 'U' in inline[5]:
            sta=inline[0][23:-8]#YN.WAD
            stalist=[sline for sline in slines if sta in sline.split(',')[0]]
            for st in stalist:
                st = st.strip();st = st.split(',')
                staloc = st[0].split('.')[0] + '  ' + st[0].split('.')[1] + '  ' + st[1] + '  ' + st[2]
                Ug = staloc + '  ' + '-12345.0000' + '  ' + eloc+ '  ' + '+1'
                FMSlist.append(Ug+'\n')
        elif 'Pg' in inline[3] and 'D' in inline[5]:
            sta=inline[0][23:-8]#YN.WAD
            stalist=[sline for sline in slines if sta in sline.split(',')[0]]
            for st in stalist:
                st = st.strip();st = st.split(',')
                staloc = st[0].split('.')[0] + '  ' + st[0].split('.')[1] + '  ' + st[1] + '  ' + st[2]
                Dg = staloc + '  ' + '-12345.0000' + '  ' + eloc+ '  ' + '-1'
                FMSlist.append(Dg+'\n')
        elif 'Pn' in inline[3] and 'U' in inline[5]:
            sta=inline[0][23:-8]#YN.WAD
            stalist=[sline for sline in slines if sta in sline.split(',')[0]]
            for st in stalist:
                st = st.strip();st = st.split(',')
                staloc = st[0].split('.')[0] + '  ' + st[0].split('.')[1] + '  ' + st[1] + '  ' + st[2]
                Un = staloc + '  ' + '-12345.0000' + '  ' + eloc+ '  ' + '+2'
                FMSlist.append(Un+'\n')
        elif 'Pn' in inline[3] and 'D' in inline[5]:
            sta=inline[0][23:-8]#YN.WAD
            stalist=[sline for sline in slines if sta in sline.split(',')[0]]
            for st in stalist:
                st = st.strip();st = st.split(',')
                staloc = st[0].split('.')[0] + '  ' + st[0].split('.')[1] + '  ' + st[1] + '  ' + st[2]
                Dn = staloc + '  ' + '-12345.0000' + '  ' + eloc+ '  ' + '-2'
                FMSlist.append(Dn+'\n')
    with open(f'files/Smart2FMS/AI/AI{name}','w') as fms:
        [fms.write(f) for f in FMSlist]
'''
