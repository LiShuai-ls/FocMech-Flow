import os,re

#AI
namedir='D:/file/Scripts/2022_07DiTingMotion/DiTingMotionJul/02DiTingMotion_分两类UD/反演FMS/DiTing2FMS'
output_gt='DT_gt1.csv'
gtpath='D:/file/Scripts/Smart_FocalMS/Ge_FMS/results/2022-07-25DiTingMotion(两类UD)'

names = os.listdir(namedir)
allgt = open(output_gt, 'w')
allgt.write('name SK1 DA1 SA1 SK2 DA2 SA2  PAZ PPL TAZ TPL BAZ BPL  MDB  RMS  REL'+'\n')
for name in names:
    name=name[:-4]
    gtlist = []
    with open(gtpath+f'/{name}.gt', 'r') as f:
        lines1 = f.readlines()[-10:]
        for line in lines1:
            line = line.strip()
            a = '  '.join(re.findall(r"\d+\.?\d{3}", line))  # 正则匹配保留三位小数的字符串 \d+\.?\d{3}
            # 131 77  191  39 79  347  355 17   85  1  180 73  0.14 5.8 0.667
            if '0' in a:
                if a in line:
                    b = name + '  ' + line
                    gtlist.append(b + '\n')
        [allgt.write(r) for r in gtlist]
allgt.close()# 为何在开始时就打开allgt？因为只需要将全部内容输入到一个文档中，不需要循环打开关闭

# #Man
# namedir='E:/workspace/YangBiEq/final_eq/files/Smart2FMS/Man'
# output_gt='D:/file/Scripts/Smart_FocalMS/Ge_FMS/results/2022-06-07删选上次结果/Man_gt.csv'
# gtpath='D:/file/Scripts/Smart_FocalMS/Ge_FMS/results/2022-06-07删选上次结果/Man'
#
# names = os.listdir(namedir)
# allgt = open(output_gt, 'w')
# allgt.write('name SK1 DA1 SA1 SK2 DA2 SA2  PAZ PPL TAZ TPL BAZ BPL  MDB  RMS  REL'+'\n')
# for name in names:
#     name=name[:-4]
#     gtlist = []
#     with open(gtpath+f'/{name}.gt', 'r') as f:
#         lines1 = f.readlines()[-10:]
#         for line in lines1:
#             line = line.strip()
#             a = '  '.join(re.findall(r"\d+\.?\d{3}", line))  # 正则匹配保留三位小数的字符串 \d+\.?\d{3}
#             # 131 77  191  39 79  347  355 17   85  1  180 73  0.14 5.8 0.667
#             if '0' in a:
#                 if a in line:
#                     b = name + '  ' + line
#                     gtlist.append(b + '\n')
#         [allgt.write(r) for r in gtlist]
# allgt.close()# 为何在开始时就打开allgt？因为只需要将全部内容输入到一个文档中，不需要循环打开关闭


