import os
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import itertools
diting_motion = tf.keras.models.load_model('D:/file/Scripts/2022_07DiTingMotion/DiTingMotionJul/DiTingMotionJul.hdf5',compile = False)
import h5py
import tensorflow as tf
import pandas as pd
import numpy as np
import time
from random import shuffle
import matplotlib.pyplot as plt
from numpy.fft import irfft, rfftfreq
from numpy import sqrt, newaxis
from numpy.random import normal
from scipy import signal
import obspy

data_length = 128
half_len = 64
temp_data_X = np.zeros([int(data_length), 2])
temp_data_Y = np.zeros([2, 3])
# sacs=os.listdir('E:/workspace/YangBiEq/final_eq/data/cutwfs/*/*Z.SAC')
#按事件预测输出
opfs=os.listdir('E:/workspace/YangBiEq/final_eq/files/Output')
for opf in opfs:
    eqn=opf[6:-4]
    f=open(f'E:/workspace/YangBiEq/final_eq/files/Output/{opf}','r');lines=f.readlines();f.close()
    stream = obspy.core.read(f'E:/workspace/YangBiEq/final_eq/data/cutwfs/{eqn}/*Z.SAC')
    oplst=[]
    for line,trace in zip(lines,stream):
        sta, stime,itp, pha, Man_Ud,sm_Ud, dist = line.split(',')
        data=trace;p_t = 200;half_len = 64
        # 以P震相为中心，前后采样64个点，组成128维度矩阵
        temp_data_X[:, 0] = data[p_t - half_len: p_t + half_len]
        # 归一化
        temp_data_X[:, 0] -= np.mean(temp_data_X[:, 0])
        norm_factor = np.max(np.abs(temp_data_X[:, 0]))
        if norm_factor == 0:
            pass
        else:
            temp_data_X[:, 0] /= norm_factor
        # 第二个通道，对震相垂直分量按P波到时作差分
        diff_data = np.diff(temp_data_X[half_len:, 0])
        diff_sign_data = np.sign(diff_data)
        temp_data_X[half_len + 1:, 1] = diff_sign_data[:]
        # 模型预测
        fmp_list = ['U', 'D']
        pred_res = diting_motion.predict(temp_data_X.reshape([1, 128, 2]))
        pred_fmp = (pred_res['T0D0'] + pred_res['T0D1'] + pred_res['T0D2'] + pred_res['T0D3']) / 4
        pred_cla = (pred_res['T1D0'] + pred_res['T1D1'] + pred_res['T1D2'] + pred_res['T1D3']) / 4
        pre_results = fmp_list[np.argmax(pred_fmp[0,:2])]#分两类：U，D
        oplst.append(sta+','+pha+','+Man_Ud+','+sm_Ud+','+pre_results+','+dist)
        # pre_results = fmp_list[np.argmax(pred_fmp[0, :2])]  # 分两类：U，D
    with open(f'Output/Output{eqn}.txt', 'w') as of:
        [of.write(a) for a in oplst]
'''
#预测所有地震震相
stream = obspy.core.read('E:/workspace/YangBiEq/final_eq/data/cutwfs/*/*Z.SAC')
SAClst=[]
for trace in stream:
    name=trace.stats.station+','+str(trace.stats.starttime)
    data = trace
    p_t=200;half_len = 64
    #以P震相为中心，前后采样64个点，组成128维度矩阵
    temp_data_X[:, 0] = data[p_t - half_len: p_t + half_len]
    #归一化
    temp_data_X[:, 0] -= np.mean(temp_data_X[:, 0])
    norm_factor = np.max(np.abs(temp_data_X[:, 0]))
    if norm_factor == 0:
        pass
    else:
        temp_data_X[:, 0] /= norm_factor
    #第二个通道，对震相垂直分量按P波到时作差分
    diff_data = np.diff(temp_data_X[half_len:, 0])
    diff_sign_data = np.sign(diff_data)
    temp_data_X[half_len + 1:, 1] = diff_sign_data[:]
    #模型预测
    fmp_list = ['U','D','-']
    pred_res = diting_motion.predict(temp_data_X.reshape([1, 128, 2]))
    pred_fmp = (pred_res['T0D0'] + pred_res['T0D1'] + pred_res['T0D2'] + pred_res['T0D3']   )/4
    pred_cla = (pred_res['T1D0'] + pred_res['T1D1'] + pred_res['T1D2'] + pred_res['T1D3']   )/4
    pre_results=fmp_list[np.argmax(pred_fmp[0])]
    SAClst.append(name+','+pre_results)
with open('D:/file/Scripts/2022_07DiTingMotion/DiTingMotionJul/DiTingRes.txt','w') as f:
    [f.write(a+'\n') for a in SAClst]
'''

'''
####################################################
# Functions for creating a training instance
####################################################
data_length = 128
half_len = 64
temp_data_X = np.zeros([int(data_length), 2])
temp_data_Y = np.zeros([2, 3])

reverse_factor = np.random.choice([-1, 1])
rescale_factor = np.random.uniform(low=0.5, high=1.5)
#
trace = obspy.core.read('E:/workspace/YangBiEq/final_eq/测试计算SNR方法/wfs/20210527T162728.290000.YN.YUX.BHZ.SAC')

data = trace[0]
p_t=200
temp_data_X[:, 0] = data[p_t - half_len: p_t + half_len]
# temp_data_X[:, 0] = data[140: 268]
temp_data_X[:, 0] -= np.mean(temp_data_X[:, 0])
norm_factor = np.max(np.abs(temp_data_X[:, 0]))
if norm_factor == 0:
    pass
else:
    temp_data_X[:, 0] /= norm_factor
#波形反转
# temp_data_X[:, 0] *= reverse_factor
# temp_data_X[:, 0] *= rescale_factor

diff_data = np.diff(temp_data_X[half_len:, 0])
diff_sign_data = np.sign(diff_data)
temp_data_X[half_len + 1:, 1] = diff_sign_data[:]

plt.figure(figsize=(12,3))
for chdx in range(2):
    temp_plot = temp_data_X[:,chdx]
    temp_plot -= np.mean(temp_plot)
    temp_plot /= np.max(np.abs(temp_plot))
    plt.plot(temp_plot + chdx*2, color='k' )
plt.plot([data_length//2,data_length//2],[-1,3],color='b',label='P')
plt.ylim([-1.3,3.3])
plt.xlim([0,temp_plot.shape[0]])
plt.yticks([])
fmp_list = ['U','D','-']
pred_res = diting_motion.predict(temp_data_X.reshape([1, 128, 2]))
pred_fmp = (pred_res['T0D0'] + pred_res['T0D1'] + pred_res['T0D2'] + pred_res['T0D3']   )/4
pred_cla = (pred_res['T1D0'] + pred_res['T1D1'] + pred_res['T1D2'] + pred_res['T1D3']   )/4
plt.title('Gt FMP: {} Pred FMP: {}\nFMP_mat: {} Clarity_mat: {}\nPred_FMP: {} Pred_Clarity: {}'.format(fmp_list[np.argmax(temp_data_Y)], fmp_list[np.argmax(pred_fmp[0])] ,temp_data_Y[0,:], temp_data_Y[1,:], pred_fmp, pred_cla))
pred_res = diting_motion.predict(temp_data_X.reshape([1, 128, 2]))
plt.legend()
plt.tight_layout()
plt.show()
# plt.close()
'''

