import os, glob,shutil
from utils import *
from obspy import read,UTCDateTime
import numpy as np

work_dir='D:/file/Scripts/04FocMech-Flow'
# 01 runPhaseNet

run_PhaseNet(work_dir)

# 02 write a time

write_atime2sac(work_dir)

# 03 DT2FMS

run_DiTing(work_dir)

# 04 run CHNYTX

